<?php
include '../db.php';
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: ../admin_login.php");
    exit();
}

// Admin ID (assumed to be 1)
$admin_id = 1;

$msg = "";

// Handle update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $stmt = $conn->prepare("UPDATE admin SET name = ?, email = ?, password = ? WHERE id = ?");
    $stmt->bind_param("sssi", $name, $email, $password, $admin_id);

    if ($stmt->execute()) {
        $msg = "Profile updated successfully!";
    } else {
        $msg = "Failed to update profile.";
    }
}

// Fetch current admin info
$stmt = $conn->prepare("SELECT name, email FROM admin WHERE id = ?");
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$stmt->bind_result($admin_name, $admin_email);
$stmt->fetch();
$stmt->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Admin Profile</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 0;
            background: #eef1f5;
        }

        .container {
            width: 450px;
            margin: 60px auto;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            color: #2575fc;
        }

        form {
            margin-top: 20px;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-top: 12px;
            border-radius: 6px;
            border: 1px solid #ccc;
        }

        .btn {
            width: 100%;
            padding: 12px;
            margin-top: 20px;
            background: #2575fc;
            border: none;
            color: white;
            font-weight: bold;
            border-radius: 6px;
            cursor: pointer;
        }

        .msg {
            text-align: center;
            color: green;
            font-weight: bold;
        }

        .back {
            text-align: center;
            margin-top: 15px;
        }

        .back a {
            color: #2575fc;
            text-decoration: none;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Edit Admin Profile</h2>
    
    <?php if ($msg): ?>
        <p class="msg"><?= $msg ?></p>
    <?php endif; ?>

    <form method="POST">
        <input type="text" name="name" placeholder="Name" value="<?= $admin_name ?>" required>
        <input type="email" name="email" placeholder="Email" value="<?= $admin_email ?>" required>
        <input type="password" name="password" placeholder="New Password" required>
        <button class="btn" type="submit">Update Profile</button>
    </form>

    <div class="back">
        <a href="admindashboard.php">← Back to Dashboard</a>
    </div>
</div>

</body>
</html>
