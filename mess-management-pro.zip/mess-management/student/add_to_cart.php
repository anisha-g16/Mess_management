<?php
session_start();
include '../db.php'; // ✅ Correct path and filename

if (!isset($_SESSION['student_id'])) {
    header("Location: ../student_login.php");
    exit();
}

// Check if a menu item has been added to the cart
if (isset($_POST['menu_id']) && isset($_POST['quantity'])) {
    $menu_id = $_POST['menu_id'];
    $quantity = $_POST['quantity'];

    // Get the menu item details from the database
    $sql = "SELECT * FROM menu WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $menu_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        // Store the selected menu item in the session cart
        $_SESSION['cart'][] = [
            'menu_id' => $row['id'],
            'menu_name' => $row['menu_name'],
            'quantity' => $quantity,
            'price' => $row['price'],
            'total_price' => $row['price'] * $quantity
        ];
    }
}

// Display the cart items
if (isset($_SESSION['cart'])) {
    $cart_items = $_SESSION['cart'];
} else {
    $cart_items = [];
}

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Add to Cart</title>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background: #f5f8fa;
        }

        /* Navbar */
        .navbar {
            background-color: #2575fc;
            overflow: hidden;
            padding: 14px 30px;
        }

        .navbar a {
            float: left;
            color: white;
            text-decoration: none;
            padding: 14px 20px;
            font-weight: bold;
        }

        .navbar a:hover {
            background-color: #1b5fd2;
        }

        h2 {
            text-align: center;
            margin: 30px 0 20px;
            color: #2575fc;
        }

        .cart-container {
            display: flex;
            flex-direction: column;
            gap: 20px;
            justify-content: center;
            padding-bottom: 50px;
            width: 50%;
            margin: 0 auto;
        }

        .cart-item {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 5px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .cart-item img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 8px;
        }

        .cart-item h3 {
            margin: 0;
            color: #333;
        }

        .cart-item p {
            margin: 5px 0;
            color: #555;
        }

        .cart-item .total-price {
            font-weight: bold;
            color: #2575fc;
        }

        .payment-btn {
            display: block;
            width: 200px;
            margin: 30px auto;
            padding: 12px;
            background-color: #2575fc;
            color: white;
            border: none;
            border-radius: 5px;
            text-align: center;
            cursor: pointer;
        }

        .payment-btn:hover {
            background-color: #1b5fd2;
        }
    </style>
</head>
<body>

    <!-- Student Navbar -->
    <div class="navbar">
        <a href="dashboard.php">Dashboard</a>
        <a href="viewmenu.php">View Menu</a>
        <a href="add_to_cart.php">Add to Cart</a>
        <!-- <a href="purchasemenu.php">Purchase Menu</a> -->
        <a href="paymenthistory.php">Payment History</a>
        <a href="../index.php">Logout</a>
    </div>

    <h2>Your Cart</h2>
    <div class="cart-container">
        <?php if (empty($cart_items)): ?>
            <p>Your cart is empty. Please add items to your cart first.</p>
        <?php else: ?>
            <?php foreach ($cart_items as $item): ?>
                <div class="cart-item">
                    <?php
                    // Get the image path for the cart item
                    $imagePath = "../admin/menu_images/" . htmlspecialchars($item['menu_name']) . ".jpg";
                    ?>
                    <img src="<?= $imagePath ?>" alt="<?= htmlspecialchars($item['menu_name']) ?>" onerror="this.src='../images/default.jpg';">
                    <div>
                        <h3><?= htmlspecialchars($item['menu_name']) ?></h3>
                        <p><strong>Quantity:</strong> <?= $item['quantity'] ?></p>
                        <p><strong>Price:</strong> ₹<?= number_format($item['price'], 2) ?></p>
                        <p class="total-price"><strong>Total:</strong> ₹<?= number_format($item['total_price'], 2) ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
            <a href="payment.php">
                <button class="payment-btn">Proceed to Payment</button>
            </a>
        <?php endif; ?>
    </div>

</body>
</html>
