<?php
session_start();
include '../db.php'; // ✅ Correct path and filename

if (!isset($_SESSION['student_id'])) {
    header("Location: ../student_login.php");
    exit();
}

$today = date('Y-m-d');

// Fetch available menu items
$sql = "SELECT * FROM menu WHERE available_date >= ? AND quantity > 0 ORDER BY available_date ASC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $today);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>View Menu</title>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background: #f5f8fa;
        }

        /* Navbar */
        .navbar {
            background-color: #2575fc;
            overflow: hidden;
            padding: 14px 30px;
        }

        .navbar a {
            float: left;
            color: white;
            text-decoration: none;
            padding: 14px 20px;
            font-weight: bold;
        }

        .navbar a:hover {
            background-color: #1b5fd2;
        }

        h2 {
            text-align: center;
            margin: 30px 0 20px;
            color: #2575fc;
        }

        .menu-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
            padding-bottom: 50px;
        }

        .menu-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            width: 260px;
            box-shadow: 0 5px 10px rgba(0,0,0,0.1);
            text-align: center;
        }

        .menu-card img {
            width: 100%;
            height: 160px;
            object-fit: cover;
            border-radius: 8px;
        }

        .menu-card h3 {
            margin-top: 10px;
            color: #333;
        }

        .menu-card p {
            margin: 5px 0;
            color: #555;
        }

        .menu-card input[type="number"] {
            width: 60px;
            padding: 6px;
            margin: 10px 0;
        }

        .menu-card button {
            padding: 8px 15px;
            background: #2575fc;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .menu-card button:hover {
            background: #1b5fd2;
        }
    </style>
</head>
<body>

    <!-- Student Navbar -->
    <div class="navbar">
        <a href="dashboard.php">Dashboard</a>
        <a href="viewmenu.php">View Menu</a>
        <a href="add_to_cart.php">Add to Cart</a>
        <!-- <a href="purchasemenu.php">Purchase Menu</a> -->
        <a href="paymenthistory.php">Payment History</a>
        <a href="../index.php">Logout</a>
    </div>

    <h2>Available Menu</h2>
    <div class="menu-container">
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="menu-card">
                <?php 
                // Get the image path from the database
                $imagePath = "../admin/" . htmlspecialchars($row['image']);
                
                // Check if the image file exists, if not use a default image
                if (!file_exists($imagePath)) {
                    $imagePath = "../images/default.jpg"; // fallback image
                }
                ?>

                <!-- Display the image -->
                <img src="<?= $imagePath ?>" alt="<?= htmlspecialchars($row['menu_name']) ?>" onerror="this.src='../images/default.jpg';">

                <h3><?= htmlspecialchars($row['menu_name']) ?></h3>
                <p><strong>Type:</strong> <?= htmlspecialchars($row['type']) ?></p>
                <p><strong>Date:</strong> <?= htmlspecialchars($row['available_date']) ?></p>
                <p><strong>Price:</strong> ₹<?= htmlspecialchars($row['price']) ?></p>
                <p><strong>Available:</strong> <?= htmlspecialchars($row['quantity']) ?></p>

                <form action="add_to_cart.php" method="POST">
                    <input type="hidden" name="menu_id" value="<?= $row['id'] ?>">
                    <input type="number" name="quantity" min="1" max="<?= $row['quantity'] ?>" required>
                    <br>
                    <button type="submit">Add to Cart</button>
                </form>
            </div>
        <?php endwhile; ?>
    </div>

</body>
</html>
