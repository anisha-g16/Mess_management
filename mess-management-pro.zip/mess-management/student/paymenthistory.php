<?php
session_start();
include '../db.php';

if (!isset($_SESSION['student_id'])) {
    header("Location: ../student_login.php");
    exit();
}

$student_id = $_SESSION['student_id'];

// Fetch payment history
$sql = "SELECT * FROM payments WHERE student_id = ? ORDER BY payment_date DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Payment History</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            background-color: #f5f8fa;
        }

        .navbar {
            background-color: #2575fc;
            padding: 14px 30px;
            overflow: hidden;
        }

        .navbar a {
            float: left;
            color: white;
            padding: 14px 20px;
            text-decoration: none;
            font-weight: bold;
        }

        .navbar a:hover {
            background-color: #1b5fd2;
        }

        h2 {
            text-align: center;
            margin: 30px 0 20px;
            color: #2575fc;
        }

        .history-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            padding: 20px;
        }

        .receipt {
            background: white;
            width: 320px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            padding: 20px;
        }

        .receipt h3 {
            margin-top: 0;
            color: #333;
        }

        .receipt p {
            margin: 8px 0;
            color: #555;
        }

        .status-success {
            color: green;
            font-weight: bold;
        }

        .status-failed {
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>

    <div class="navbar">
        <a href="dashboard.php">Dashboard</a>
        <a href="viewmenu.php">View Menu</a>
        <a href="add_to_cart.php">Add to Cart</a>
        <a href="paymenthistory.php">Payment History</a>
        <a href="../index.php">Logout</a>
    </div>

    <h2>Your Payment History</h2>

    <div class="history-container">
        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="receipt">
                    <h3>Receipt</h3>
                    <p><strong>Payment ID:</strong> <?= $row['id'] ?></p>
                    <p><strong>Cardholder:</strong> <?= htmlspecialchars($row['cardholder_name']) ?></p>
                    <p><strong>Card Number:</strong> **** **** **** <?= substr($row['card_number'], -4) ?></p>
                    <p><strong>Amount:</strong> ₹<?= $row['total_amount'] ?></p>
                    <p><strong>Status:</strong>
                        <span class="<?= $row['payment_status'] === 'success' ? 'status-success' : 'status-failed' ?>">
                            <?= ucfirst($row['payment_status']) ?>
                        </span>
                    </p>
                    <p><strong>Date:</strong> <?= $row['payment_date'] ?></p>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p style="text-align:center;">No payment history found.</p>
        <?php endif; ?>
    </div>

</body>
</html>