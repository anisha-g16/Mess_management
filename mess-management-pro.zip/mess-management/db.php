<?php
$host = "localhost"; // XAMPP default
$user = "root";      // XAMPP default
$password = "";      // Empty by default
$database = "mess_management"; // The DB name you created

// Create connection
$conn = new mysqli($host, $user, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("❌ Connection failed: " . $conn->connect_error);
} else {
    // Optional: Display success message
    // echo "✅ Connected successfully!";
}
?>
