<?php
// logout.php - Handles logout for both admin and student

session_start();

// Unset all session variables
session_unset();

// Destroy the session
session_destroy();

// Redirect to home or login page
header("Location: index.php"); // change to login.php if you prefer
exit();
?>
