<?php
session_start();
include '../db.php';

if (!isset($_SESSION['student_id'])) {
    header("Location: ../student_login.php");
    exit();
}

$student_id = $_SESSION['student_id'];
$total_price = 0;

// Calculate total from cart
if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $total_price += $item['total_price'];
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['card_number'])) {
    $card_number = $_POST['card_number'];
    $cardholder_name = $_POST['cardholder_name'];
    $password = $_POST['password'];
    $status = $_POST['payment_result']; // success or failed

    // Insert payment
    $stmt = $conn->prepare("INSERT INTO payments (student_id, card_number, cardholder_name, password, total_amount, payment_status) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssds", $student_id, $card_number, $cardholder_name, $password, $total_price, $status);
    $stmt->execute();

    if ($status === "success") {
        unset($_SESSION['cart']);
        header("Location: viewmenu.php");
    } else {
        header("Location: add_to_cart.php");
    }
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Payment</title>
    <meta charset="UTF-8">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f5f8fa;
            text-align: center;
            margin: 0;
            padding: 0;
        }

        .navbar {
            background-color: #2575fc;
            padding: 14px 30px;
            overflow: hidden;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            padding: 14px 20px;
            font-weight: bold;
            float: left;
        }

        .navbar a:hover {
            background-color: #1b5fd2;
        }

        .container {
            margin-top: 60px;
        }

        .btn {
            padding: 12px 25px;
            background-color: #2575fc;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin: 10px;
        }

        .btn:hover {
            background-color: #1b5fd2;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            background: rgba(0,0,0,0.5);
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background: white;
            padding: 30px;
            border-radius: 10px;
            width: 350px;
        }

        .modal-content input {
            width: 100%;
            margin: 10px 0;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .modal-content button {
            width: 48%;
            padding: 10px;
            margin-top: 10px;
        }

        .title {
            color: #2575fc;
        }
    </style>
</head>
<body>

<div class="navbar">
    <a href="dashboard.php">Dashboard</a>
    <a href="viewmenu.php">View Menu</a>
    <a href="add_to_cart.php">Add to Cart</a>
    <a href="paymenthistory.php">Payment History</a>
    <a href="../index.php">Logout</a>
</div>

<div class="container">
    <h2 class="title">Your Total Payment: ₹<?= number_format($total_price, 2) ?></h2>
    <button class="btn" onclick="document.getElementById('paymentModal').style.display='flex'">Proceed to Pay</button>
</div>

<!-- Payment Modal -->
<div id="paymentModal" class="modal">
    <div class="modal-content">
        <h3>Enter Card Details</h3>
        <form id="paymentForm" method="POST">
            <input type="text" name="card_number" placeholder="Card Number" required>
            <input type="text" name="cardholder_name" placeholder="Cardholder Name" required>
            <input type="password" name="password" placeholder="Card Password" required>
            <input type="hidden" name="payment_result" id="payment_result">
            <div style="display: flex; justify-content: space-between;">
                <button type="button" class="btn" onclick="submitPayment('success')">Payment Successful</button>
                <button type="button" class="btn" onclick="submitPayment('failed')">Fail Payment</button>
            </div>
        </form>
    </div>
</div>

<script>
function submitPayment(status) {
    document.getElementById("payment_result").value = status;
    document.getElementById("paymentForm").submit();
}
</script>

</body>
</html>
