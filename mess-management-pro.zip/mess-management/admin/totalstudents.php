<?php
include '../db.php';
session_start();

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: ../admin_login.php");
    exit();
}

$msg = "";

// Update student
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_student'])) {
    $id = $_POST['id'];
    $name = $_POST['full_name'];
    $email = $_POST['email'];

    $stmt = $conn->prepare("UPDATE student SET full_name = ?, email = ? WHERE id = ?");
    $stmt->bind_param("ssi", $name, $email, $id);
    if ($stmt->execute()) {
        $msg = "Student updated successfully!";
    } else {
        $msg = "Update failed.";
    }
}

// Get all students
$students = $conn->query("SELECT * FROM students");

?>

<!DOCTYPE html>
<html>
<head>
    <title>Total Students</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 0;
            background: #f0f2f5;
        }

        .container {
            width: 90%;
            margin: 40px auto;
            background: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 6px 15px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            color: #2575fc;
        }

        .msg {
            text-align: center;
            color: green;
            font-weight: bold;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 25px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
        }

        th {
            background-color: #2575fc;
            color: white;
        }

        form input {
            padding: 5px;
            width: 90%;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .btn {
            padding: 8px 14px;
            background: green;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .back {
            text-align: center;
            margin-top: 20px;
        }

        .back a {
            text-decoration: none;
            color: #2575fc;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Total Students</h2>
    <?php if ($msg): ?>
        <p class="msg"><?= $msg ?></p>
    <?php endif; ?>

    <table>
        <tr>
            <th>ID</th>
            <th>Full Name</th>
            <th>Email</th>
            <th>Edit</th>
        </tr>

        <?php while ($row = $students->fetch_assoc()): ?>
        <tr>
            <form method="POST">
                <td><?= $row['id'] ?></td>
                <td><input type="text" name="full_name" value="<?= $row['full_name'] ?>"></td>
                <td><input type="email" name="email" value="<?= $row['email'] ?>"></td>
                <td>
                    <input type="hidden" name="id" value="<?= $row['id'] ?>">
                    <button type="submit" name="update_student" class="btn">Update</button>
                </td>
            </form>
        </tr>
        <?php endwhile; ?>
    </table>

    <div class="back">
        <a href="admindashboard.php">← Back to Dashboard</a>
    </div>
</div>

</body>
</html>
