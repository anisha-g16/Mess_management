const images = [
    'images/dosa.jpg',
    'images/idli.jpg',
    'images/samosa.jpg'
];

let index = 0;
const sliderImage = document.getElementById("sliderImage");

function changeImage() {
    index = (index + 1) % images.length;
    sliderImage.src = images[index];
}

setInterval(changeImage, 3000);
