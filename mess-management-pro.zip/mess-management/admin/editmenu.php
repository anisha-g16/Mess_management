<?php
include '../db.php';
session_start();

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: ../admin_login.php");
    exit();
}

// Handle update request
$updateMsg = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_menu'])) {
    $id = $_POST['id'];
    $menu_name = $_POST['menu_name'];
    $type = $_POST['type'];
    $available_date = $_POST['available_date'];
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];

    $stmt = $conn->prepare("UPDATE menu SET menu_name=?, type=?, available_date=?, price=?, quantity=? WHERE id=?");
    $stmt->bind_param("ssssdi", $menu_name, $type, $available_date, $price, $quantity, $id);

    if ($stmt->execute()) {
        $updateMsg = "Menu updated successfully!";
    } else {
        $updateMsg = "Failed to update menu.";
    }
}

// Fetch all menu items
$menus = $conn->query("SELECT * FROM menu");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Menu</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f4f6f8;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 95%;
            margin: 40px auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            color: #2575fc;
        }

        .msg {
            color: green;
            text-align: center;
            margin: 10px 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 25px;
        }

        table th, table td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: center;
        }

        table th {
            background: #2575fc;
            color: white;
        }

        form input, form select {
            padding: 6px;
            width: 100%;
        }

        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .edit-btn {
            background: orange;
            color: white;
        }

        .delete-btn {
            background: crimson;
            color: white;
        }

        .update-btn {
            background: green;
            color: white;
        }

        .back-link {
            text-align: center;
            margin-top: 20px;
        }

        .back-link a {
            text-decoration: none;
            color: #2575fc;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Edit & Delete Menu Items</h2>

    <?php if ($updateMsg): ?>
        <p class="msg"><?= $updateMsg ?></p>
    <?php endif; ?>

    <table>
        <tr>
            <th>ID</th>
            <th>Menu Name</th>
            <th>Type</th>
            <th>Date</th>
            <th>Price</th>
            <th>Qty</th>
            <th>Image</th>
            <th>Actions</th>
        </tr>

        <?php while ($row = $menus->fetch_assoc()): ?>
        <tr>
            <form method="POST">
                <td><?= $row['id'] ?></td>
                <td><input type="text" name="menu_name" value="<?= $row['menu_name'] ?>"></td>
                <td>
                    <select name="type">
                        <option value="Breakfast" <?= $row['type'] == 'Breakfast' ? 'selected' : '' ?>>Breakfast</option>
                        <option value="Lunch" <?= $row['type'] == 'Lunch' ? 'selected' : '' ?>>Lunch</option>
                        <option value="Dinner" <?= $row['type'] == 'Dinner' ? 'selected' : '' ?>>Dinner</option>
                    </select>
                </td>
                <td><input type="date" name="available_date" value="<?= $row['available_date'] ?>"></td>
                <td><input type="number" step="0.01" name="price" value="<?= $row['price'] ?>"></td>
                <td><input type="number" name="quantity" value="<?= $row['quantity'] ?>"></td>
                <td>
                    <img src="<?= $row['image'] ?>" width="60" height="50">
                </td>
                <td>
                    <input type="hidden" name="id" value="<?= $row['id'] ?>">
                    <button class="btn update-btn" type="submit" name="update_menu">Update</button>
                    <a class="btn delete-btn" href="deletemenu.php?id=<?= $row['id'] ?>" onclick="return confirm('Are you sure to delete?')">Delete</a>
                </td>
            </form>
        </tr>
        <?php endwhile; ?>
    </table>

    <div class="back-link">
        <a href="admindashboard.php">← Back to Dashboard</a>
    </div>
</div>

</body>
</html>
