<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: ../student_login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Student Dashboard</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 0;
            background: #f0f4f8;
        }

        /* NAVBAR STYLING */
        .navbar {
            background-color: #2575fc;
            overflow: hidden;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 40px;
            height: 60px;
        }

        .navbar .logo {
            color: #fff;
            font-size: 22px;
            font-weight: bold;
            text-transform: uppercase;
        }

        .navbar a {
            color: #fff;
            padding: 14px 20px;
            text-decoration: none;
            font-size: 16px;
            transition: background 0.3s;
        }

        .navbar a:hover {
            background-color: #1d5fd9;
            border-radius: 4px;
        }

        .welcome-box {
            max-width: 600px;
            margin: 100px auto;
            background: #fff;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .welcome-box h1 {
            color: #333;
            font-size: 28px;
        }

        .welcome-box p {
            color: #666;
            font-size: 18px;
        }

        .nav-links {
            display: flex;
            gap: 10px;
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <div class="navbar">
        <div class="logo">Student Dashboard</div>
        <div class="nav-links">
            <a href="viewmenu.php">View Menu</a>
            <a href="add_to_cart.php">Add to Cart</a>
            <!-- <a href="purchasemenu.php">Purchase Menu</a> -->
            <a href="paymenthistory.php">Payment History</a>
            <a href="../index.php">Logout</a>
        </div>
    </div>

    <!-- Welcome Message -->
    <div class="welcome-box">
        <h1>Welcome, <?= htmlspecialchars($_SESSION['student_name']); ?>!</h1>
        <p>Explore your dashboard options from the top menu.</p>
    </div>

</body>
</html>
