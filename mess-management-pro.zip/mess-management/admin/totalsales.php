<?php
session_start();
include '../db.php';

$totalSales = 0.00;

$sql = "SELECT 
            students.full_name AS student_name, 
            payments.card_number, 
            payments.cardholder_name, 
            payments.total_amount, 
            payments.payment_date 
        FROM payments 
        JOIN students ON payments.student_id = students.id 
        WHERE payments.payment_status = 'success' 
        ORDER BY payments.payment_date DESC";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Total Sales Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f7f7f7;
            margin: 0;
            padding: 20px;
        }
        h2 {
            color: #333;
            text-align: center;
            margin-bottom: 30px;
        }
        table {
            width: 90%;
            margin: auto;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        th, td {
            border: 1px solid #ccc;
            padding: 12px 15px;
            text-align: center;
        }
        th {
            background-color: #2575fc;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .total {
            margin-top: 20px;
            text-align: center;
            font-size: 20px;
            color: #2575fc;
            font-weight: bold;
        }
        .back {
            display: block;
            width: 120px;
            margin: 20px auto;
            padding: 10px;
            text-align: center;
            background: #2575fc;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .back:hover {
            background: #1b5fd2;
        }
    </style>
</head>
<body>

    <h2>Total Sales Report</h2>

    <table>
        <tr>
            <th>Student Name</th>
            <th>Card Holder</th>
            <th>Card Number</th>
            <th>Amount (₹)</th>
            <th>Date</th>
        </tr>
        <?php while($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['student_name']) ?></td>
                <td><?= htmlspecialchars($row['cardholder_name']) ?></td>
                <td><?= htmlspecialchars($row['card_number']) ?></td>
                <td>₹<?= number_format($row['total_amount'], 2) ?></td>
                <td><?= $row['payment_date'] ?></td>
            </tr>
            <?php $totalSales += $row['total_amount']; ?>
        <?php endwhile; ?>
    </table>

    <div class="total">
        Total Sales: ₹<?= number_format($totalSales, 2) ?>
    </div>

    <a href="admindashboard.php" class="back">← Back</a>

</body>
</html>
