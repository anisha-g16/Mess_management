<?php
include '../db.php';
session_start();

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: ../admin_login.php");
    exit();
}

$msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $menu_name = $_POST['menu_name'];
    $type = $_POST['type'];
    $available_date = $_POST['available_date'];
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];

    // Handle image upload
    $image_name = $_FILES['image']['name'];
    $image_tmp = $_FILES['image']['tmp_name'];
    $image_path = "menu_images/" . basename($image_name);

    if (move_uploaded_file($image_tmp, $image_path)) {
        // Insert into database
        $stmt = $conn->prepare("INSERT INTO menu (menu_name, type, image, available_date, price, quantity) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssdi", $menu_name, $type, $image_path, $available_date, $price, $quantity);
        if ($stmt->execute()) {
            $msg = "Menu added successfully!";
        } else {
            $msg = "Failed to add menu!";
        }
        $stmt->close();
    } else {
        $msg = "Image upload failed!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Menu</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 0;
            background: #f4f6f8;
        }

        .container {
            width: 600px;
            margin: 50px auto;
            background: #fff;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            color: #2575fc;
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
        }

        input, select {
            width: 100%;
            padding: 10px;
            margin-top: 6px;
            border: 1px solid #ccc;
            border-radius: 6px;
        }

        button {
            margin-top: 20px;
            width: 100%;
            padding: 12px;
            background: #2575fc;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background: #1a5edb;
        }

        .msg {
            text-align: center;
            margin-top: 15px;
            font-weight: bold;
            color: green;
        }

        .back-link {
            text-align: center;
            margin-top: 10px;
        }

        .back-link a {
            color: #2575fc;
            text-decoration: none;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Add Menu Item</h2>

    <?php if ($msg): ?>
        <p class="msg"><?= $msg ?></p>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
        <label for="menu_name">Menu Name</label>
        <input type="text" id="menu_name" name="menu_name" required>

        <label for="type">Menu Type</label>
        <select id="type" name="type" required>
            <option value="">-- Select Type --</option>
            <option value="Breakfast">Breakfast</option>
            <option value="Lunch">Lunch</option>
            <option value="Dinner">Dinner</option>
        </select>

        <label for="image">Image Upload</label>
        <input type="file" id="image" name="image" accept="image/*" required>

        <label for="available_date">Available Date</label>
        <input type="date" id="available_date" name="available_date" required>

        <label for="price">Price (₹)</label>
        <input type="number" id="price" name="price" step="0.01" required>

        <label for="quantity">Quantity</label>
        <input type="number" id="quantity" name="quantity" required>

        <button type="submit">Add Menu</button>
        <div class="back-link"><a href="admindashboard.php">← Back to Dashboard</a></div>
    </form>
</div>

</body>
</html>
