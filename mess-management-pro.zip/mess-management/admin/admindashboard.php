<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: ../admin_login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f4f4;
        }

        .sidebar {
            position: fixed;
            width: 220px;
            height: 100%;
            background: #2575fc;
            padding-top: 40px;
            color: white;
        }

        .sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 22px;
        }

        .sidebar a {
            display: block;
            padding: 15px 25px;
            text-decoration: none;
            color: white;
            font-size: 16px;
            transition: background 0.3s ease;
        }

        .sidebar a:hover {
            background-color: #1a5edb;
        }

        .main-content {
            margin-left: 220px;
            padding: 40px;
        }

        .main-content h1 {
            color: #333;
            font-size: 28px;
        }

        .main-content p {
            font-size: 16px;
            color: #666;
        }

    </style>
</head>
<body>

<div class="sidebar">
    <h2>Admin Panel</h2>
    <a href="admindashboard.php">Dashboard</a>
    <a href="addmenu.php">Add Menu</a>
    <a href="editmenu.php">Edit Menu</a>
    <a href="totalstudents.php">Total Students</a>
    <a href="totalsales.php">Total Sales</a>
    <a href="editprofile.php">Edit Profile</a>
    <a href="../index.php">Logout</a>
</div>

<div class="main-content">
    <h1>Welcome, Admin!</h1>
    <p>Select an option from the left menu to manage the mess system.</p>
</div>

</body>
</html>
