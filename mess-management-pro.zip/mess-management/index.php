<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Anna Purna Caterins</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <header>
        <div class="container">
            <h1 class="logo">ANNA PURNA CATERINS</h1>
            <nav>
                <ul class="nav-links">
                    <li><a href="#">Home</a></li>
                    <li><a href="registration.php">Student Registration</a></li>
                    <li><a href="student_login.php">Student Login</a></li>
                    <li><a href="admin_login.php">Admin Login</a></li>
                    <li><a href="#">Menu</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="slider">
        <img id="sliderImage" src="images/menu1.jpg" alt="Mess Menu Image">
    </section>

    <footer>
        <p>&copy; 2025 Anna Purna Caterins. All Rights Reserved.</p>
    </footer>

    <script src="js/script.js"></script>
</body>
</html>
